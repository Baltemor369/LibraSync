

from typing import Any


class Book:
    def __init__(self, title:str="",  author:str="", type:str="", tome:int=0, read=0) -> None:
        self.title = title
        self.author = author
        self.type = type
        self.tome = tome
        self.read = read

    def __eq__(self, __o: object) -> bool:
        check = True
        if self.title != __o.title :
            check = False
        if self.author != __o.author :
            check = False
        if self.tome != __o.tome:
            check = False
        return check

    def __repr__(self) -> str:
        return "title:{}\nauthor:{}\ntype:{}\ntome:{}\nread:{}\n".format(self.title, self.author, self.type, self.tome, self.read)

    def modify(self, new_title:str="", new_author:str="", new_type:str="", new_tome:int=-1) -> None:
        if new_title: 
            self.title = new_title
        if new_author:
            self.author = new_author
        if new_type:
            self.type = new_type
        if new_tome!=-1:
            self.tome = new_tome
        